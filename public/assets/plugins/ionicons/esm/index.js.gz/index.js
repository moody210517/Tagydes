// ionicons: ES Module
export * from './es5/ionicons.define.js';